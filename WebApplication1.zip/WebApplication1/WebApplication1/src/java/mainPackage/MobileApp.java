/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainPackage;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.logging.Level;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import java.util.regex.Matcher; 
import java.util.regex.Pattern;



@Path("mobileApp")
public class MobileApp {
    

public boolean isValid(String email) 
    { 
        final String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                            "[a-zA-Z0-9_+&*-]+)*@" + 
                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                            "A-Z]{2,7}$"; 
                              
        Pattern pat = Pattern.compile(emailRegex); 
        if (email == null) 
            return false; 
        return pat.matcher(email).matches(); 
    } 

    @Context
    private UriInfo context;

    public MobileApp() {
    }

    @GET
    @Path("test")
    @Produces("application/json")
    public String getJson() {

        return "{\"name\":\"Akashdeep Sharma\"}";
    }

    @GET
    @Path("UsersList")
    @Produces("application/json")
    public String getXml() {

        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();
        obj.accumulate("Status", "Error");
        obj.accumulate("Epoch Time", time);
        JSONArray Jarray = new JSONArray();
        try {

            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
            Statement stm = con.createStatement();
            String sql = "select * from users";

            ResultSet rs = stm.executeQuery(sql);

            JSONObject UsersList = new JSONObject();

            int USERID;
            String GENDER, PHONENUMBER;
            String EMAILID, FIRSTNAME, LASTNAME, PASSWORD;
            if (rs.next() == false) {
                obj.accumulate("Message", "Something went wrong");
            }
            else{
                do{
                    obj.clear();
                    obj.accumulate("Status", "Ok");
                    obj.accumulate("Epoch Time", time);
                    USERID = rs.getInt("USER_ID");
                    FIRSTNAME = rs.getString("FIRST_NAME");
                    LASTNAME = rs.getString("LAST_NAME");
                    GENDER = rs.getString("GENDER");
                    EMAILID = rs.getString("EMAIL_ID");

                    PASSWORD = rs.getString("PASSWORD");

                    PHONENUMBER = rs.getString("PHONE_NUMBER");

                    UsersList.accumulate("USERID", USERID);
                    UsersList.accumulate("FIRSTNAME", FIRSTNAME);
                    UsersList.accumulate("LASTNAME", LASTNAME);
                    UsersList.accumulate("GENDER", GENDER);
                    UsersList.accumulate("EMAILID", EMAILID);
                    UsersList.accumulate("PASSWORD", PASSWORD);
                    UsersList.accumulate("PHONENUMBER", PHONENUMBER);
                    Jarray.add(UsersList);
                    UsersList.clear();
                }while (rs.next());
                obj.accumulate("List", Jarray);
            }
            
            
            rs.close();
            stm.close();
            con.close();

        } catch (ClassNotFoundException | SQLException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj.toString();

    }

    @GET
    @Path("user_Profile&{email}")
    @Produces("application/json")
    public String getXml3(@PathParam("email") String email) {
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();
        obj.accumulate("Status", "Error");
        obj.accumulate("Epoch Time", time);
        JSONArray Jarray = new JSONArray();
        try {

            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
            Statement stm = con.createStatement();
            String sql = "select * from users where email_id="+"'"+email+"'";

            ResultSet rs = stm.executeQuery(sql);
            if (rs.next() == false) {
                obj.accumulate("Message", "User does not exist");
            }
            else{
                    JSONObject userProfile = new JSONObject();
                    int USERID;
                    String GENDER, PHONENUMBER;
                    String EMAILID, FIRSTNAME, LASTNAME, PASSWORD;
            
                do{
                    obj.clear();
                    obj.accumulate("Status", "OK");
                    obj.accumulate("Epoch Time", time);
                    USERID = rs.getInt("USER_ID");
                FIRSTNAME = rs.getString("FIRST_NAME");
                LASTNAME = rs.getString("LAST_NAME");
                GENDER = rs.getString("GENDER");
                EMAILID = rs.getString("EMAIL_ID");

                PASSWORD = rs.getString("PASSWORD");

                PHONENUMBER = rs.getString("PHONE_NUMBER");

                userProfile.accumulate("USERID", USERID);
                userProfile.accumulate("FIRSTNAME", FIRSTNAME);
                userProfile.accumulate("LASTNAME", LASTNAME);
                userProfile.accumulate("GENDER", GENDER);
                userProfile.accumulate("EMAILID", EMAILID);
                userProfile.accumulate("PASSWORD", PASSWORD);
                userProfile.accumulate("PHONENUMBER", PHONENUMBER);
                Jarray.add(userProfile);
                userProfile.clear();
                }
            while (rs.next());
            obj.accumulate("UserInfo", Jarray);
            }
            
            rs.close();
            stm.close();
            con.close();

        } catch (ClassNotFoundException | SQLException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj.toString();

    }

    @GET
    @Path("Login&{id}&{pass}")
    @Produces("application/json")
    public String getXml2(@PathParam("id") String emlID, @PathParam("pass") String password) {
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();
        obj.accumulate("Status", "Error");
        obj.accumulate("Epoch Time", time);
        try {

            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
            Statement stm = con.createStatement();

            //String sql = "select * from users where email_id='akash@gmail,con'";
            String sql = "select * from users where email_id=" + "'" + emlID + "' and password=" + "'" + password + "'";
            ResultSet rs = stm.executeQuery(sql);

            if (rs.next() == false) {
                obj.accumulate("Message", "Incorrect Username or Password");
            } else {
                obj.clear();
				obj.accumulate("UserId", rs.getInt("USER_ID"));
                obj.accumulate("Status", "OK");
                obj.accumulate("Epoch Time", time);
                obj.accumulate("Message", "Successfully Login");
            }

            con.close();

        } catch (ClassNotFoundException | SQLException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj.toString();

    }

    
    @GET
    @Path("questionList")
    @Produces("application/json")
    public String getxml1() {
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();

        obj.accumulate("status", "Error");
        obj.accumulate("EpochTime", time);
        JSONArray mainJSON = new JSONArray();
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
            Statement stm = con.createStatement();
            String sql = "select * from question";
            ResultSet rs = stm.executeQuery(sql);

            JSONObject question = new JSONObject();

            int question_id,quiz_id;
            String ques_text;
            String created_by;
            Timestamp creation_date;
            if (rs.next() == false) {
                obj.accumulate("Message", "Something went wrong");
            } else {
                do{
                obj.clear();
                obj.accumulate("status", "OK");
                obj.accumulate("EpochTime", time);
                question_id = rs.getInt("ques_id");
                quiz_id = rs.getInt("quiz_id");
                ques_text = rs.getString("ques_text");
                created_by = rs.getString("created_by");
                creation_date = rs.getTimestamp("creation_date");
                //  c_date = rs.getDate("creation_date");
                question.accumulate("question_id", question_id);
                question.accumulate("quiz_id", quiz_id);
                question.accumulate("ques_text", ques_text);
                question.accumulate("created_by", created_by);
                question.accumulate("creation_date", creation_date);

                // singleEmployee.accumulate("creation_date", c_date); */
                mainJSON.add(question);
                question.clear();
                }
            while (rs.next()); 
                
                obj.accumulate("List", mainJSON);
            }
            
            rs.close();
            stm.close();
            con.close();
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj.toString();

    }

    @GET
    @Path("result&{user_id}")
    @Produces("application/json")
    public String getxml(@PathParam("user_id") String usrID) {
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();

        obj.accumulate("status", "Error");
        obj.accumulate("EpochTime", time);
        JSONArray mainJSON = new JSONArray();
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
            Statement stm = con.createStatement();

            String sql = "select * from result where user_id=" + "'" + usrID + "'";

            ResultSet rs = stm.executeQuery(sql);

            JSONObject result = new JSONObject();

            int result_id,correct_answer = 0, attempt_question = 0, score,incorrect_answer, quiz_id, user_id;
            double score1;
            Timestamp date_quiz;
            if (rs.next() == false) {
                obj.accumulate("Message", "No Result for this user");
            } else {
                do{
                    
                    
                    obj.clear();
                    obj.accumulate("status", "OK");
                    obj.accumulate("EpochTime", time);
                    result_id = rs.getInt("result_id");
                    correct_answer = rs.getInt("correct_ans");
                    attempt_question = rs.getInt("attempt_ques");
                    incorrect_answer = rs.getInt("incorrect_ans");
                    score1 = (correct_answer * 100)/attempt_question;
                    score = rs.getInt("score");
                    date_quiz = rs.getTimestamp("date_quiz");
                    quiz_id = rs.getInt("quiz_id");
                    user_id = rs.getInt("user_id");
                    //  c_date = rs.getDate("creation_date");
                    
                    result.accumulate("result_id", result_id);
                    result.accumulate("correct_answer", correct_answer);
                    result.accumulate("attempt_question", attempt_question);
                    result.accumulate("incorrect_answer", incorrect_answer);
                    result.accumulate("score", score1);
                    result.accumulate("date_quiz", date_quiz);
                    result.accumulate("quiz_id", quiz_id);
                    result.accumulate("user_id", user_id);
                    // singleEmployee.accumulate("creation_date", c_date); */

                    mainJSON.add(result);
                    result.clear();
                    obj.accumulate("Result", mainJSON);
                }
            while (rs.next());
            }
            
            rs.close();
            stm.close();
            con.close();
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj.toString();

    }

    @GET
    @Path("optionsList")
    @Produces("application/json")
    public String getxm2() {
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();

        obj.accumulate("status", "Error");
        obj.accumulate("EpochTime", time);
        JSONArray mainJSON = new JSONArray();
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
            Statement stm = con.createStatement();

            String sql = "select * from options";

            ResultSet rs = stm.executeQuery(sql);

            JSONObject option = new JSONObject();

            int option_id, question_id;
            String options_text, right_ans;
            Timestamp creation_date;
            if (rs.next() == false) {
                obj.accumulate("Message", "Something went wrong");
            } else {
                do{
                obj.clear();
                obj.accumulate("status", "OK");
                obj.accumulate("EpochTime", time);
                 
                option_id = rs.getInt("option_id");
                question_id = rs.getInt("ques_id");
                options_text = rs.getString("option_text");
                right_ans = rs.getString("right_ans");
                creation_date = rs.getTimestamp("creation_date");
                //  c_date = rs.getDate("creation_date");

                option.accumulate("option_id", option_id);
                option.accumulate("question_id", question_id);
                option.accumulate("options_text", options_text);
                option.accumulate("right_ans", right_ans);
                option.accumulate("creation_date", creation_date);

                // singleEmployee.accumulate("creation_date", c_date); */
                mainJSON.add(option);
                option.clear();
                }
                while (rs.next());
               obj.accumulate("Option_List", mainJSON);
                }
            
            rs.close();
            stm.close();
            con.close();
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj.toString();

    }
    
    
    
    @GET
    @Path("QuestionOptions&{ques_id}")
    @Produces("application/json")
    public String getxm4(@PathParam ("ques_id") int ques_id) {
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();

        obj.accumulate("status", "Error");
        obj.accumulate("EpochTime", time);
        JSONArray mainJSON = new JSONArray();
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
            Statement stm = con.createStatement();

            String sql = "select * from options where ques_id=" + "'" + ques_id + "'";

            ResultSet rs = stm.executeQuery(sql);

            JSONObject option = new JSONObject();

            int option_id, question_id;
            String options_text, right_ans;
            Timestamp creation_date;
            if (rs.next() == false) {
                obj.accumulate("Message", "Something went wrong");
            } else {
                do{
                obj.clear();
                obj.accumulate("status", "OK");
                obj.accumulate("EpochTime", time);
                 
                option_id = rs.getInt("option_id");
                question_id = rs.getInt("ques_id");
                options_text = rs.getString("option_text");
                right_ans = rs.getString("right_ans");
                creation_date = rs.getTimestamp("creation_date");
                //  c_date = rs.getDate("creation_date");

                option.accumulate("option_id", option_id);
                option.accumulate("question_id", question_id);
                option.accumulate("options_text", options_text);
                option.accumulate("right_ans", right_ans);
                option.accumulate("creation_date", creation_date);

                // singleEmployee.accumulate("creation_date", c_date); */
                mainJSON.add(option);
                option.clear();
                }
                while (rs.next());
               obj.accumulate("Option_List", mainJSON);
                }
            
            rs.close();
            stm.close();
            con.close();
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj.toString();

    }

    
    
    

    @GET
    @Path("categoryList")
    @Produces("application/json")
    public String getxm5() {
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();

        obj.accumulate("status", "Error");
        obj.accumulate("EpochTime", time);
        JSONArray mainJSON = new JSONArray();
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
            Statement stm = con.createStatement();
            
            String sql = "select * from category";
            ResultSet rs = stm.executeQuery(sql);
            JSONObject CategoriesList = new JSONObject();
            
            int cat_id;
            String cat_name;

            if (rs.next() == false) {
                obj.accumulate("Message", "Something went wrong");
            } else {
            do{    
            obj.clear();
            obj.accumulate("status", "Ok");
            obj.accumulate("EpochTime", time);
            cat_id = rs.getInt("cat_id");
            cat_name = rs.getString("cat_name");
            CategoriesList.accumulate("cat_id", cat_id);
            CategoriesList.accumulate("cat_name", cat_name);
            mainJSON.add(CategoriesList);
            CategoriesList.clear();
            }
            while (rs.next()); 
            obj.accumulate("list", mainJSON);
            }    
            rs.close();
            stm.close();
            con.close();
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj.toString();
    }
   
    public boolean UniEmailCheck(String emailId)
    {
        boolean checkEmail = true ;
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
            Statement stm = con.createStatement();

            String sql = "select * from users where email_id=" + "'" + emailId + "'" ;
            ResultSet rs = stm.executeQuery(sql);

            if (rs.next() == false)
            {
                checkEmail = false;
            }
          
            con.close();

        } catch (ClassNotFoundException | SQLException ex)
        {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return checkEmail;
    }

    @GET
    @Path("Registration&{first_name}&{last_name}&{gender}&{email_id}&{password}&{phone_number}")
    @Produces("application/json")
    public String getXml7(@PathParam ("first_name") String first_name,@PathParam ("last_name") String last_name,@PathParam ("gender") String gender,@PathParam ("email_id") String email_id,@PathParam ("password") String password,@PathParam ("phone_number") int phone_number )
    {   
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();
        obj.accumulate("Status", "Error");
        obj.accumulate("EpochTime", time);
        JSONArray mainJSON = new JSONArray();
        String check;
        if(!isValid(email_id))
        {
            obj.accumulate("Message", "Wrong email entered");
        }
        else if(UniEmailCheck(email_id) == true)
        {
            obj.accumulate("Message", "Email id already exist");
        }
        else
        {
            try 
            {
                Class.forName("oracle.jdbc.OracleDriver");
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
                Statement stm = con.createStatement();
                String sql2="SELECT * FROM ( SELECT * FROM users ORDER BY user_id DESC) WHERE ROWNUM = 1";
            ResultSet rs2 = stm.executeQuery(sql2);
            if (rs2.next() == false) {
                
                
            } 
            check = rs2.getString("user_id");    
            int result = Integer.parseInt(check);		
                result=result+1;
                
            
            String sql = "insert into users(user_id,first_name,last_name,gender,email_id,password,phone_number) values(" + result + ", '" + first_name + "' , '" +last_name+"' , '" + gender + "' , '"+email_id+"' , '"+password+"' , "+phone_number+")";
            

                

                ResultSet rs = stm.executeQuery(sql);
                if (rs.next() == false) {
                    obj.accumulate("Message", "Wrong information Entered");
                } else {
                    obj.clear();
                    obj.accumulate("Status", "Ok");
                    obj.accumulate("EpochTime", time);
                    obj.accumulate("Message", "Registered successfully");   
                }
                rs.close();
                stm.close();
                con.close();

            }
            catch (SQLException ex)
            {
                java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
            }
            catch (ClassNotFoundException ex)
            {
                java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return obj.toString();
        
    }
    
    
    @GET
    @Path("AddResult&{user_id}&{quiz_id}&{correct_ans}&{attempt_ques}&{incorrect_ans}")
    @Produces("application/json")
    public String getXml11(@PathParam ("user_id") int user_id,@PathParam ("quiz_id") int quiz_id,@PathParam ("correct_ans") int correct_ans,@PathParam ("attempt_ques") int attempt_ques,@PathParam ("incorrect_ans") int incorrect_ans)
    {   
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();
        obj.accumulate("Status", "Error");
        obj.accumulate("EpochTime", time);
        JSONArray mainJSON = new JSONArray();
        int score1;
        score1 = (correct_ans * 100)/attempt_ques;
        String check;
            try 
            {
                Class.forName("oracle.jdbc.OracleDriver");
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
                Statement stm = con.createStatement();
                
                String sql2="SELECT count(*) FROM RESULT";
            ResultSet rs2 = stm.executeQuery(sql2);
            
            int count=0;
            while(rs2.next()){
                            

        count = rs2.getInt("count(*)");
    }
            
            
            
           
           		
                count=count+1;
                
                String sql = "insert into result(result_id,user_id,quiz_id,correct_ans,attempt_ques,incorrect_ans,score) values(" + count + ", " + user_id + " , " +quiz_id+ " , " + correct_ans + " , " +attempt_ques+ " , " +incorrect_ans+" , " +score1+ ")";
                
                ResultSet rs = stm.executeQuery(sql);
                if (rs.next() == false) {
                    obj.accumulate("Message", "Wrong information Entered");
                } else {
                    obj.clear();
                    obj.accumulate("Status", "Ok");
                    obj.accumulate("EpochTime", time);
                    obj.accumulate("Message", "Result added successfully");   
                }
                rs.close();
                stm.close();
                con.close();
            }
            catch (SQLException ex)
            {
                java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
            }
            catch (ClassNotFoundException ex)
            {
                java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        return obj.toString();
    }
    
    
    
    @GET
    @Path("ShareResult&{user_id}&{share_email_id}")
    @Produces("application/json")
    public String getXml10(@PathParam ("user_id") int user_id,@PathParam ("share_email_id") String email_id )
    {   
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();
        obj.accumulate("Status", "Error");
        obj.accumulate("EpochTime", time);
        JSONArray mainJSON = new JSONArray();
        
                   try 
            {
                Class.forName("oracle.jdbc.OracleDriver");
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
                Statement stm = con.createStatement();

                
                String sql = "UPDATE result SET share_with ="+ "'"+email_id+ "' where user_id=" +  user_id;
                
                ResultSet rs = stm.executeQuery(sql);
                
                if (rs.next() == false) {
                    obj.accumulate("Message", "Result not Shared");
                } else {
                    obj.clear();
                    obj.accumulate("Status", "Ok");
                    obj.accumulate("EpochTime", time);
                    obj.accumulate("Message", "Result Shared successfully");   
                }
                rs.close();
                stm.close();
                con.close();

            }
            catch (SQLException ex)
            {
                java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
            }
            catch (ClassNotFoundException ex)
            {
                java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        return obj.toString();
        
    }
    
    
    
    @GET
    @Path("ViewSharedResults&{email_id}")
    @Produces("application/json")
    public String getxml11(@PathParam("email_id") String emlID) {
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();

        obj.accumulate("status", "Error");
        obj.accumulate("EpochTime", time);
        JSONArray mainJSON = new JSONArray();
        String check;
        int correct,incorrect,attempt,score;
        int num=0;
        String fst_nm,lst_nm;
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
            Statement stm = con.createStatement();

            
            
            
            String sql2 = "select user_id from result where share_with=" + "'" + emlID + "'";
            
            ResultSet rs2 = stm.executeQuery(sql2);
            if (rs2.next() == false) {}
            while(rs2.next()){
                num = rs2.getInt("user_id"); 
            }
             
            
            
            String sql = "select email_id from users where user_id=" + "'" + num + "'";
            
            ResultSet rs = stm.executeQuery(sql);
            
            if (rs.next() == false) {} 
            
            check = rs.getString("email_id"); 
            
            
            
            String sql3 = "select * from result where user_id=" + "'" + num + "'";

            ResultSet rs3 = stm.executeQuery(sql3);
            //if (rs3.next() == false) {} 
            //correct = rs.getInt("correct_ans");
            //incorrect = rs.getInt("incorrect_ans");
            //attempt = rs.getInt("attempt_ques");
            
            
            JSONObject result = new JSONObject();

            
            double score1;
            
            Timestamp date_quiz;
            if (rs3.next() == false) {
                obj.accumulate("Message", "No Result Shared");
            } else {
                //do{
                    
                    
                    obj.clear();
                    obj.accumulate("status", "OK");
                    obj.accumulate("EpochTime", time);
                    
                    //fst_nm = rs3.getString("share_with");
                    correct = rs3.getInt("correct_ans");
                    incorrect = rs3.getInt("incorrect_ans");
                    attempt = rs3.getInt("attempt_ques");
                    score = rs3.getInt("score");
                    
                    //result.accumulate("UserName", fst_nm);
                    result.accumulate("email_id", check);
                    result.accumulate("correct", correct);
                    result.accumulate("incorrect", incorrect);
                    result.accumulate("attempt", attempt);
                    result.accumulate("score", score);
                    

                    mainJSON.add(result);
                    result.clear();
                    obj.accumulate("Info", mainJSON);
               // }
            //while (rs3.next());
            }
            
            rs3.close();
            stm.close();
            con.close();
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj.toString();

    }
    
    
    
    
    
    @GET
    @Path("SearchFriend&{id}")
    @Produces("application/json")
    public String getXml8(@PathParam("id") String emlID) {
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();
        obj.accumulate("Status", "Error");
        obj.accumulate("Epoch Time", time);
        try {

            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
            Statement stm = con.createStatement();

            //String sql = "select * from users where email_id='akash@gmail,con'";
            String sql = "select * from users where email_id=" + "'" + emlID + "'" ;
            
            ResultSet rs = stm.executeQuery(sql);
            
            if (rs.next() == false) {
                obj.accumulate("Message", "Friend not found");
            } else {
                obj.clear();
                obj.accumulate("Status", "Ok");
        obj.accumulate("Epoch Time", time);
                obj.accumulate("Message", "Friend found");
               
            }

            con.close();

        } catch (ClassNotFoundException | SQLException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj.toString();

    }
    
    @GET
    @Path("SelectCategory&{name}")
    @Produces("application/json")
    public String getXml9(@PathParam("name") String cat_name) {
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();
        obj.accumulate("Status", "Error");
        obj.accumulate("Epoch Time", time);
        try {

            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam2", "any1pw");
            Statement stm = con.createStatement();

            //String sql = "select * from users where email_id='akash@gmail,con'";
            String sql = "select * from CATEGORY where CAT_NAME = " + "'" + cat_name + "'" ;
            ResultSet rs = stm.executeQuery(sql);
            if (rs.next() == false) {
                obj.accumulate("Message", "Category does not exist");
            } else {
                obj.clear();
                obj.accumulate("Status", "Ok");
                obj.accumulate("Epoch Time", time);
                obj.accumulate("Message", "Category selected");
            }

            con.close();

        } catch (ClassNotFoundException | SQLException ex) {
            java.util.logging.Logger.getLogger(MobileApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj.toString();

    }

}
