package com.muskan.quizapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.muskan.quizapp.api.ApiConnection;
import com.muskan.quizapp.api.OnApiResponseListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class QuizActivity extends AppCompatActivity implements View.OnClickListener {

    TextView OptionA, OptionB, OptionC, OptionD, Question, NoofQuestion, tvTimer;
    String[] list_Answer, list_Answered;
    Button btnNext, btnSubmit;
    ProgressBar progressBar;
    int QuestionIndex = 0, TotalQuestion = 5, CorrectAnswer = 0, WrongAnswer = 0;
    CardView CardA, CardB, CardC, CardD;
    int QuizId = 0;
    private List<Question> questionList;
    Boolean isCancel;
    CountDownTimer timer;
    SharedPreferences sharedPrefs;
    int userId = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        sharedPrefs = getSharedPreferences(Const.SHAREDPREFERENCE, MODE_PRIVATE);
        userId = sharedPrefs.getInt(Const.UserId, 0);

        questionList = new ArrayList<>();
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        OptionA = (TextView) findViewById(R.id.tvOptA);
        OptionB = (TextView) findViewById(R.id.tvOptB);
        OptionC = (TextView) findViewById(R.id.tvOptC);
        OptionD = (TextView) findViewById(R.id.tvOptD);
        NoofQuestion = (TextView) findViewById(R.id.noofquestion);

        Question = (TextView) findViewById(R.id.question);
        tvTimer = (TextView) findViewById(R.id.tvTimer);

        btnNext = (Button) findViewById(R.id.btnNext);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);

        OptionA.setOnClickListener(this);
        OptionB.setOnClickListener(this);
        OptionC.setOnClickListener(this);
        OptionD.setOnClickListener(this);
        btnNext.setOnClickListener(this);
        btnSubmit.setOnClickListener(this);

        CardA = (CardView) findViewById(R.id.optionA);
        CardB = (CardView) findViewById(R.id.optionB);
        CardC = (CardView) findViewById(R.id.optionC);
        CardD = (CardView) findViewById(R.id.optionD);
        CardA.setVisibility(View.INVISIBLE);
        CardB.setVisibility(View.INVISIBLE);
        CardC.setVisibility(View.INVISIBLE);
        CardD.setVisibility(View.INVISIBLE);
        list_Answer = new String[5];
        list_Answered = new String[5];
        getQuestions();


    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btnNext:
                try {

                    CardA.setVisibility(View.INVISIBLE);
                    CardB.setVisibility(View.INVISIBLE);
                    CardC.setVisibility(View.INVISIBLE);
                    CardD.setVisibility(View.INVISIBLE);

                    OptionA.setEnabled(true);
                    OptionB.setEnabled(true);
                    OptionC.setEnabled(true);
                    OptionD.setEnabled(true);
                    QuestionIndex++;
                    SetQuestion(QuestionIndex);
                } catch (NullPointerException n) {
                    n.printStackTrace();
                }
                break;

            case R.id.btnSubmit:
                saveResult();


                break;

            case R.id.tvOptA:
                CheckAnswer("A");
                if (TextUtils.equals(list_Answer[QuestionIndex], "A")) {
                    CorrectAnswer++;
                } else {
                    WrongAnswer++;
                }


                break;
            case R.id.tvOptB:
                CheckAnswer("B");
                if (TextUtils.equals(list_Answer[QuestionIndex], "B")) {
                    CorrectAnswer++;
                } else {
                    WrongAnswer++;
                }


                break;
            case R.id.tvOptC:
                CheckAnswer("C");
                if (TextUtils.equals(list_Answer[QuestionIndex], "C")) {
                    CorrectAnswer++;
                } else {
                    WrongAnswer++;
                }
                break;
            case R.id.tvOptD:
                CheckAnswer("D");
                if (TextUtils.equals(list_Answer[QuestionIndex], "D")) {
                    CorrectAnswer++;
                } else {
                    WrongAnswer++;
                }
                break;
        }

    }

    void CheckAnswer(String SelectedOption) {
        isCancel = true;
        try {
            if (TotalQuestion == (QuestionIndex + 1)) {
                btnNext.setEnabled(false);
                btnNext.setVisibility(Button.INVISIBLE);
                btnSubmit.setVisibility(Button.VISIBLE);
            } else {
                btnNext.setEnabled(true);
                btnSubmit.setVisibility(Button.INVISIBLE);
            }

            list_Answered[QuestionIndex] = SelectedOption;

            if (!TextUtils.equals(SelectedOption, list_Answer[QuestionIndex])) {
                if (TextUtils.equals(SelectedOption, "A")) {
                    CardA.setCardBackgroundColor(Color.parseColor("#ff3822"));
                } else if (TextUtils.equals(SelectedOption, "B")) {
                    CardB.setCardBackgroundColor(Color.parseColor("#ff3822"));
                } else if (TextUtils.equals(SelectedOption, "C")) {
                    CardC.setCardBackgroundColor(Color.parseColor("#ff3822"));
                } else if (TextUtils.equals(SelectedOption, "D")) {
                    CardD.setCardBackgroundColor(Color.parseColor("#ff3822"));
                }

            }
            if (TextUtils.equals(list_Answer[QuestionIndex], "A")) {
                CardA.setCardBackgroundColor(Color.parseColor("#92d36e"));
            } else if (TextUtils.equals(list_Answer[QuestionIndex], "B")) {
                CardB.setCardBackgroundColor(Color.parseColor("#92d36e"));
            } else if (TextUtils.equals(list_Answer[QuestionIndex], "C")) {
                CardC.setCardBackgroundColor(Color.parseColor("#92d36e"));
            } else if (TextUtils.equals(list_Answer[QuestionIndex], "D")) {
                CardD.setCardBackgroundColor(Color.parseColor("#92d36e"));
            }
            OptionA.setEnabled(false);
            OptionB.setEnabled(false);
            OptionC.setEnabled(false);
            OptionD.setEnabled(false);
        } catch (NullPointerException n) {
            Log.d("NullPointerException", n.getMessage());
        }

    }

    void SetQuestion(int QuestionIndex) {

        NoofQuestion.setText((QuestionIndex + 1) + "/" + TotalQuestion);

        try {


            CardA.setCardBackgroundColor(Color.parseColor("#ffffff"));
            CardB.setCardBackgroundColor(Color.parseColor("#ffffff"));
            CardC.setCardBackgroundColor(Color.parseColor("#ffffff"));
            CardD.setCardBackgroundColor(Color.parseColor("#ffffff"));

            Question question = questionList.get(QuestionIndex);


            Question.setText(question.getQuestion());
            getOptions(question.getQuestionId());

            //  Explanation.setText(list_Explaination[QuestionIndex]);
            //  Explanation.setVisibility(TextView.INVISIBLE);

            // getSupportActionBar().setTitle("Quiz             " + String.valueOf(QuestionIndex + 1) + "/" + String.valueOf(TotalQuestion));
            btnNext.setEnabled(false);
        } catch (NullPointerException n) {
            Log.d("NullPointerException", n.getMessage());
        }


    }

    void saveResult() {

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {

                    String Url = "http://10.0.2.2:8080/QuizApp/main/mobileApp/AddResult&" + userId + "&3&" + CorrectAnswer + "&" + TotalQuestion + "&" + WrongAnswer;
                    Log.e("Url", Url);
                    new ApiConnection().connect(new OnApiResponseListener() {
                        @Override
                        public void onSuccess(JSONObject jsonObject) {
                           // try {


                                Log.e("RESPONSE", jsonObject.toString());

                                Intent i = new Intent(QuizActivity.this, QuizResultActivity.class);
                                i.putExtra("total_question", TotalQuestion);
                                i.putExtra("correct_answer", CorrectAnswer);
                                i.putExtra("wrong_answer", WrongAnswer);
                                i.putExtra("quiz_id", QuizId);
                                startActivity(i);
                                finish();

/*

                            } catch (JSONException e) {
                                e.printStackTrace();

                            }
*/

                        }

                        @Override
                        public void onFailed(String message) {
                            // avLoadingIndicatorView.hide();
                            Toast.makeText(QuizActivity.this, "Oops something went wrong..", Toast.LENGTH_SHORT).show();

                        }
                    }, null, Url);

                } catch (Exception e) {


                }
            }
        });
    }

    void getQuestions() {

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {

                    String Url = "http://10.0.2.2:8080/QuizApp/main/mobileApp/questionList";
                    Log.e("Url", Url);
                    new ApiConnection().connect(new OnApiResponseListener() {
                        @Override
                        public void onSuccess(JSONObject jsonObject) {
                            try {


                                Log.e("RESPONSE", jsonObject.toString());


                                JSONArray jsonArray = jsonObject.getJSONArray("List");
                                if (jsonArray.length() > 0) {
                                    for (int j = 0; j < jsonArray.length(); j++) {

                                        JSONObject jsn = jsonArray.getJSONObject(j);

                                        Question question = new Question(jsn.getInt("question_id"), jsn.getString("ques_text")
                                        );
                                        questionList.add(question);
                                    }


                                    SetQuestion(QuestionIndex);

                                } else {
                                    Toast.makeText(QuizActivity.this, "No Quiz to display", Toast.LENGTH_SHORT).show();
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();

                            }

                        }

                        @Override
                        public void onFailed(String message) {
                            // avLoadingIndicatorView.hide();
                            Toast.makeText(QuizActivity.this, "Oops something went wrong..", Toast.LENGTH_SHORT).show();

                        }
                    }, null, Url);

                } catch (Exception e) {


                }
            }
        });
    }

    void getOptions(final int QuestionId) {

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {

                    String Url = "http://10.0.2.2:8080/QuizApp/main/mobileApp/QuestionOptions&" + QuestionId;
                    Log.e("Url", Url);
                    new ApiConnection().connect(new OnApiResponseListener() {
                        @Override
                        public void onSuccess(JSONObject jsonObject) {
                            try {


                                Log.e("RESPONSE", jsonObject.toString());


                                JSONArray jsonArray = jsonObject.getJSONArray("Option_List");
                                if (jsonArray.length() > 0) {
                                    for (int j = 0; j < 1; j++) {

                                        JSONObject jsn = jsonArray.getJSONObject(j);

                                        String options = jsn.getString("options_text");

                                        // splitting String by comma, it will return array
                                        String[] array = options.split(",");


                                        OptionA.setText(array[0]);
                                        OptionB.setText(array[1]);
                                        OptionC.setText(array[2]);
                                        OptionD.setText(array[3]);
                                        Log.e("QuestionIndex", "" + QuestionIndex);
                                        if (TextUtils.equals(array[0], jsn.getString("right_ans"))) {
                                            list_Answer[QuestionIndex] = "A";
                                        } else if (TextUtils.equals(array[1], jsn.getString("right_ans"))) {
                                            list_Answer[QuestionIndex] = "B";
                                        } else if (TextUtils.equals(array[2], jsn.getString("right_ans"))) {
                                            list_Answer[QuestionIndex] = "C";
                                        } else if (TextUtils.equals(array[3], jsn.getString("right_ans"))) {
                                            list_Answer[QuestionIndex] = "D";
                                        }
                                        CardA.setVisibility(View.VISIBLE);
                                        CardB.setVisibility(View.VISIBLE);
                                        CardC.setVisibility(View.VISIBLE);
                                        CardD.setVisibility(View.VISIBLE);
                                        isCancel = false;
                                        timer = new CountDownTimer(15000, 1000) {

                                            public void onTick(long millisUntilFinished) {

                                                if (isCancel) {
                                                    cancel();
                                                } else {
                                                    tvTimer.setText("" + millisUntilFinished / 1000);
                                                }


                                            }

                                            public void onFinish() {
                                                WrongAnswer++;
                                                if (TotalQuestion == (QuestionIndex + 1)) {
                                                    btnNext.setEnabled(false);
                                                    btnNext.setVisibility(Button.INVISIBLE);
                                                    btnSubmit.setVisibility(Button.VISIBLE);
                                                    Intent i = new Intent(QuizActivity.this, QuizResultActivity.class);
                                                    i.putExtra("total_question", TotalQuestion);
                                                    i.putExtra("correct_answer", CorrectAnswer);
                                                    i.putExtra("wrong_answer", WrongAnswer);
                                                    i.putExtra("quiz_id", QuizId);
                                                    startActivity(i);
                                                    finish();
                                                } else {
                                                    CardA.setVisibility(View.INVISIBLE);
                                                    CardB.setVisibility(View.INVISIBLE);
                                                    CardC.setVisibility(View.INVISIBLE);
                                                    CardD.setVisibility(View.INVISIBLE);
                                                    btnNext.setEnabled(true);
                                                    btnSubmit.setVisibility(Button.INVISIBLE);
                                                    OptionA.setEnabled(true);
                                                    OptionB.setEnabled(true);
                                                    OptionC.setEnabled(true);
                                                    OptionD.setEnabled(true);
                                                    QuestionIndex++;
                                                    SetQuestion(QuestionIndex);
                                                }
                                            }

                                        }.start();

                                    }


                                } else {
                                    Toast.makeText(QuizActivity.this, "No Quiz to display", Toast.LENGTH_SHORT).show();
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();

                            }

                        }

                        @Override
                        public void onFailed(String message) {
                            // avLoadingIndicatorView.hide();
                            Toast.makeText(QuizActivity.this, "Oops something went wrong..", Toast.LENGTH_SHORT).show();

                        }
                    }, null, Url);

                } catch (Exception e) {


                }
            }
        });
    }
}
