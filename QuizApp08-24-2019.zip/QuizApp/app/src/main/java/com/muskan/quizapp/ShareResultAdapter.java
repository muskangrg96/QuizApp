package com.muskan.quizapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class ShareResultAdapter extends RecyclerView.Adapter<ShareResultAdapter.ViewHolder> {

    ShareResult shareResult;
    private Context context;
    private List<ShareResult> shareResultList;


    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView tvEmail, tvScore, tvIncorrect, tvCorrect, tvTotal;


        public ViewHolder(View view) {
            super(view);

            tvTotal = (TextView) view.findViewById(R.id.tvTotal);
            tvEmail = (TextView) view.findViewById(R.id.tvEmail);
            tvScore = (TextView) view.findViewById(R.id.tvScore);
            tvIncorrect = (TextView) view.findViewById(R.id.tvIncorrect);
            tvCorrect = (TextView) view.findViewById(R.id.tvCorrect);


        }


    }

    public ShareResultAdapter(Context mContext, List<ShareResult> shareResultList) {
        this.context = mContext;
        this.shareResultList = shareResultList;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_share_result, parent, false);


        return new ViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        shareResult = shareResultList.get(position);
        holder.tvScore.setText("Score : " + shareResult.getScore() +"%");
        holder.tvEmail.setText("Shared by : " + shareResult.getEmail());
        holder.tvIncorrect.setText("Incorrect : " + shareResult.getIncorrect());
        holder.tvCorrect.setText("Correct : " + shareResult.getCorrect());
        holder.tvTotal.setText("Total Question : " + shareResult.getTotal());


    }

    @Override
    public int getItemCount() {
        return shareResultList.size();
    }
}