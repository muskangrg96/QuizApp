package com.muskan.quizapp.api;


public class ApiConfig {


    private static final String BASE_URL = "http://leads.greenbooksolutions.in/appaccess/";




}