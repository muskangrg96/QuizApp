package com.muskan.quizapp;

public class Const {

    public static String SHAREDPREFERENCE = "preference";
    public static final String UserId = "userIdKey";
    public static final String Email = "emailKey";


}
