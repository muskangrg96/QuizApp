package com.muskan.quizapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class UserProfileActivity extends AppCompatActivity {

    TextView tvName, tvGender;
    String Name, Gender;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        Name = getIntent().getStringExtra("name");
        Gender = getIntent().getStringExtra("gender");

        tvName = (TextView) findViewById(R.id.tvName);
        tvGender = (TextView) findViewById(R.id.tvGender);


        tvGender.setText("Gender : " + Gender);
        tvName.setText("Name : " + Name);
    }
}
