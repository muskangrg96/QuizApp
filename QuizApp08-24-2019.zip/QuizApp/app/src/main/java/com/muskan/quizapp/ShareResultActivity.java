package com.muskan.quizapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.muskan.quizapp.api.ApiConnection;
import com.muskan.quizapp.api.OnApiResponseListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ShareResultActivity extends AppCompatActivity {

    private List<User> userList;
    AppCompatButton btnSearch, btnShare;
    EditText etSearch;
    String email;
    TextView tvName, tvEmail;
    SharedPreferences sharedPrefs;
    int userId = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_result);
        sharedPrefs = getSharedPreferences(Const.SHAREDPREFERENCE, MODE_PRIVATE);
        userId = sharedPrefs.getInt(Const.UserId, 0);
        userList = new ArrayList<>();
        etSearch = (EditText) findViewById(R.id.etSearch);
        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        btnShare = findViewById(R.id.btnShare);
        btnShare.setVisibility(View.INVISIBLE);
        btnSearch = findViewById(R.id.btnSearch);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email = etSearch.getText().toString();

                for (int i = 0; i < userList.size(); i++) {
                    User user = userList.get(i);
                    if (user.email.contains(email)) {
                        tvName.setText(user.getName());
                        tvEmail.setText(user.getEmail());
                        btnShare.setVisibility(View.VISIBLE);

                    }

                }
            }
        });
        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shareResult();
            }
        });
        getUsers();
    }

    void shareResult() {

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {

                    String Url = "http://10.0.2.2:8080/QuizApp/main/mobileApp/ShareResult&" + userId + "&" + tvEmail.getText().toString();
                    Log.e("Url", Url);
                    new ApiConnection().connect(new OnApiResponseListener() {
                        @Override
                        public void onSuccess(JSONObject jsonObject) {
                            try {


                                Log.e("RESPONSE", jsonObject.toString());


                                if (jsonObject.has("Status")) {
                                    Toast.makeText(ShareResultActivity.this, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                                    finish();

                                } else {
                                    Toast.makeText(ShareResultActivity.this, "Failed to Share result", Toast.LENGTH_SHORT).show();
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();

                            }

                        }

                        @Override
                        public void onFailed(String message) {
                            // avLoadingIndicatorView.hide();
                            Toast.makeText(ShareResultActivity.this, "Oops something went wrong..", Toast.LENGTH_SHORT).show();

                        }
                    }, null, Url);

                } catch (Exception e) {


                }
            }
        });
    }

    void getUsers() {

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {

                    String Url = "http://10.0.2.2:8080/QuizApp/main/mobileApp/UsersList";
                    Log.e("Url", Url);
                    new ApiConnection().connect(new OnApiResponseListener() {
                        @Override
                        public void onSuccess(JSONObject jsonObject) {
                            try {


                                Log.e("RESPONSE", jsonObject.toString());


                                JSONArray jsonArray = jsonObject.getJSONArray("List");
                                if (jsonArray.length() > 0) {
                                    for (int j = 0; j < jsonArray.length(); j++) {

                                        JSONObject jsn = jsonArray.getJSONObject(j);

                                        User user = new User(jsn.getInt("USERID"), jsn.getString("FIRSTNAME") + " " + jsn.getString("LASTNAME"),
                                                jsn.getString("EMAILID"), jsn.getString("GENDER"));
                                        userList.add(user);
                                    }


                                } else {
                                    Toast.makeText(ShareResultActivity.this, "No User to display", Toast.LENGTH_SHORT).show();
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();

                            }

                        }

                        @Override
                        public void onFailed(String message) {
                            // avLoadingIndicatorView.hide();
                            Toast.makeText(ShareResultActivity.this, "Oops something went wrong..", Toast.LENGTH_SHORT).show();

                        }
                    }, null, Url);

                } catch (Exception e) {


                }
            }
        });
    }
}
