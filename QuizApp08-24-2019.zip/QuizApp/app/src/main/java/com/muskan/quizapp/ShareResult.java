package com.muskan.quizapp;

public class ShareResult {

    private String email, total, correct, incorrect, score;

    public ShareResult(String email, String total, String correct, String incorrect, String score) {
        this.email = email;
        this.total = total;
        this.correct = correct;
        this.incorrect = incorrect;
        this.score = score;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getCorrect() {
        return correct;
    }

    public void setCorrect(String correct) {
        this.correct = correct;
    }

    public String getIncorrect() {
        return incorrect;
    }

    public void setIncorrect(String incorrect) {
        this.incorrect = incorrect;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }
}
