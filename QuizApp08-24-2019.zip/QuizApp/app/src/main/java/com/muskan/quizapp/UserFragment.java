package com.muskan.quizapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.muskan.quizapp.api.ApiConnection;
import com.muskan.quizapp.api.OnApiResponseListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserFragment extends Fragment {

    private List<User> userList, filteredList;
    UserAdapter adapter;
    EditText etSearch;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_users, container, false);
        etSearch = (EditText) v.findViewById(R.id.etSearch);

        userList = new ArrayList<>();
        filteredList = new ArrayList<>();
        RecyclerView recyclerView = (RecyclerView) v.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        adapter = new UserAdapter(getContext(), filteredList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(adapter);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.length() > 4) {
                    filteredList.clear();
                    for (int i = 0; i < userList.size(); i++) {
                        User user = userList.get(i);
                        if (user.name.contains(editable)) {
                            filteredList.add(user);
                        }

                    }
                    if(filteredList.size()==0){
                        Toast.makeText(getActivity(), "No User found", Toast.LENGTH_SHORT).show();
                    }else{
                        adapter.notifyDataSetChanged();
                    }


                }

            }
        });


        getUsers();


        return v;
    }

    void getUsers() {

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {

                    String Url = "http://10.0.2.2:8080/QuizApp/main/mobileApp/UsersList";
                    Log.e("Url", Url);
                    new ApiConnection().connect(new OnApiResponseListener() {
                        @Override
                        public void onSuccess(JSONObject jsonObject) {
                            try {


                                Log.e("RESPONSE", jsonObject.toString());


                                JSONArray jsonArray = jsonObject.getJSONArray("List");
                                if (jsonArray.length() > 0) {
                                    for (int j = 0; j < jsonArray.length(); j++) {

                                        JSONObject jsn = jsonArray.getJSONObject(j);

                                        User user = new User(jsn.getInt("USERID"), jsn.getString("FIRSTNAME") + " " + jsn.getString("LASTNAME"),
                                                jsn.getString("EMAILID"),jsn.getString("GENDER"));
                                        userList.add(user);
                                    }


                                } else {
                                    Toast.makeText(getActivity(), "No User to display", Toast.LENGTH_SHORT).show();
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();

                            }

                        }

                        @Override
                        public void onFailed(String message) {
                            // avLoadingIndicatorView.hide();
                            Toast.makeText(getActivity(), "Oops something went wrong..", Toast.LENGTH_SHORT).show();

                        }
                    }, null, Url);

                } catch (Exception e) {


                }
            }
        });
    }


}
