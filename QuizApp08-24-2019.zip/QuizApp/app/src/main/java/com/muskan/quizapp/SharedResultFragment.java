package com.muskan.quizapp;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.muskan.quizapp.api.ApiConnection;
import com.muskan.quizapp.api.OnApiResponseListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

public class SharedResultFragment extends Fragment {

    private List<ShareResult> shareResultList;
    ShareResultAdapter adapter;
    SharedPreferences sharedPrefs;
    String email;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_shared_result, container, false);

        sharedPrefs = getActivity().getSharedPreferences(Const.SHAREDPREFERENCE, MODE_PRIVATE);
        email = sharedPrefs.getString(Const.Email, "");


        shareResultList = new ArrayList<>();
        RecyclerView recyclerView = (RecyclerView) v.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        adapter = new ShareResultAdapter(getContext(), shareResultList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(adapter);

        getSharedResults();


        return v;
    }

    void getSharedResults() {

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {

                    String Url = "http://10.0.2.2:8080/QuizApp/main/mobileApp/ViewSharedResults&" + email;
                    Log.e("Url", Url);
                    new ApiConnection().connect(new OnApiResponseListener() {
                        @Override
                        public void onSuccess(JSONObject jsonObject) {
                            try {


                                Log.e("RESPONSE", jsonObject.toString());

                                if(TextUtils.equals(jsonObject.getString("status"),"Error")){
                                    Toast.makeText(getActivity(), "No result to display", Toast.LENGTH_SHORT).show();

                                }else{
                                    JSONArray jsonArray = jsonObject.getJSONArray("Info");
                                    if (jsonArray.length() > 0) {
                                        for (int j = 0; j < jsonArray.length(); j++) {

                                            JSONObject jsn = jsonArray.getJSONObject(j);

                                            ShareResult shareResult = new ShareResult(jsn.getString("email_id"), jsn.getString("attempt"),
                                                    jsn.getString("correct"), jsn.getString("incorrect"), jsn.getString("score"));
                                            shareResultList.add(shareResult);
                                        }
                                        adapter.notifyDataSetChanged();

                                    } else {
                                        Toast.makeText(getActivity(), "No result to display", Toast.LENGTH_SHORT).show();
                                    }
                                }




                            } catch (JSONException e) {
                                e.printStackTrace();

                            }

                        }

                        @Override
                        public void onFailed(String message) {
                            // avLoadingIndicatorView.hide();
                            Toast.makeText(getActivity(), "Oops something went wrong..", Toast.LENGTH_SHORT).show();

                        }
                    }, null, Url);

                } catch (Exception e) {


                }
            }
        });
    }


}
