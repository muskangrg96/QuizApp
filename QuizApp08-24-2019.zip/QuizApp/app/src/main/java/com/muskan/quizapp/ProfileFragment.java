package com.muskan.quizapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.muskan.quizapp.api.ApiConnection;
import com.muskan.quizapp.api.OnApiResponseListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.content.Context.MODE_PRIVATE;

public class ProfileFragment extends Fragment {


    SharedPreferences sharedPrefs;
    int userId = 0;
    String Email;
    TextView tvName, tvGender, tvEmail, tvMobile;
    private CircleImageView ivProfile;
    File imageFile;
     String ImageName = "0";


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_profile, container, false);
        tvName = (TextView) v.findViewById(R.id.tvName);
        tvGender = (TextView) v.findViewById(R.id.tvGender);
        tvEmail = (TextView) v.findViewById(R.id.tvEmail);
        tvMobile = (TextView) v.findViewById(R.id.tvPhone);

        sharedPrefs = getActivity().getSharedPreferences(Const.SHAREDPREFERENCE, MODE_PRIVATE);
        userId = sharedPrefs.getInt(Const.UserId, 0);
        Email = sharedPrefs.getString(Const.Email, "");
        ivProfile = (CircleImageView) v.findViewById(R.id.ivProfile);
        ivProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int permission = ContextCompat.checkSelfPermission(getActivity(),
                        Manifest.permission.WRITE_EXTERNAL_STORAGE);
                int permission1 = ContextCompat.checkSelfPermission(getActivity(),
                        Manifest.permission.CAMERA);
                int premission2 = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE);

                if (permission != PackageManager.PERMISSION_GRANTED || permission1 != PackageManager.PERMISSION_GRANTED || premission2 != PackageManager.PERMISSION_GRANTED) {
                    Log.i("data2", "Permission to record denied");

                    if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                            Manifest.permission.WRITE_EXTERNAL_STORAGE) || ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                            Manifest.permission.CAMERA) || ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                            Manifest.permission.READ_EXTERNAL_STORAGE)) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setMessage("Permission to access the CAMERA and SD-CARD is required app.")
                                .setTitle("Permission required");

                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int id) {

                                makeRequest();

                            }
                        });

                        AlertDialog dialog = builder.create();
                        dialog.show();

                    } else {

                        makeRequest();

                    }

                } else {
                    makeRequest();

                }
            }

        });



        getProfile();
        return v;
    }
    protected void makeRequest() {

        requestPermissions(
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA},
                300);
    }


    private void showImageOptions() {

        final CharSequence[] options = {"Take Photo", "Choose from Gallery"};
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Upload Profile Image");
        builder.setItems(options, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (options[item].equals("Take Photo")) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, 1);
                } else if (options[item].equals("Choose from Gallery")) {
                    Intent intent = new Intent(
                            Intent.ACTION_GET_CONTENT);
                    intent.setType("image/*");
                    startActivityForResult(
                            intent,
                            2);
                }
            }
        });
        builder.show();

    }


    @Override

    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == getActivity().RESULT_OK) {

            if (requestCode == 1) {

                Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                if (thumbnail != null) {
                    thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, bytes);

                }
                ImageName = System.currentTimeMillis() + ".jpeg";
                File destination = new File(Environment.getExternalStorageDirectory(),
                        ImageName);
                FileOutputStream fo;
                try {
                    destination.createNewFile();
                    fo = new FileOutputStream(destination);
                    fo.write(bytes.toByteArray());
                    fo.close();
                    imageFile = destination;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                // byte[] b = bytes.toByteArray();
                Bitmap myBitmap = BitmapFactory.decodeFile(destination.getAbsolutePath());
                ivProfile.setImageBitmap(myBitmap);


            } else if (requestCode == 2) {
                Uri imageUri = data.getData();


                try {
                    Bitmap bm = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);
                    int nh = (int) (bm.getHeight() * (512.0 / bm.getWidth()));
                    bm = Bitmap.createScaledBitmap(bm, 512, nh, true);
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    if (bm != null) {
                        bm.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                        System.out.print(bytes.size());
                    }
                    ImageName = System.currentTimeMillis() + ".jpeg";
                    File destination = new File(Environment.getExternalStorageDirectory(),
                            ImageName);
                    FileOutputStream fo;
                    try {
                        destination.createNewFile();
                        fo = new FileOutputStream(destination);
                        fo.write(bytes.toByteArray());
                        fo.close();
                        imageFile = destination;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Bitmap myBitmap = BitmapFactory.decodeFile(destination.getAbsolutePath());
                    ivProfile.setImageBitmap(myBitmap);


                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {

            case 300: {

                if (grantResults.length == 0
                        || grantResults[0] !=
                        PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(getActivity(), "You have to grant CAMERA and SD card Write permission for image upload", Toast.LENGTH_SHORT).show();

                } else {

                    showImageOptions();
                }

            }

        }
    }

    void getProfile() {

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {

                    String Url = "http://10.0.2.2:8080/QuizApp/main/mobileApp/user_Profile&" + Email;
                    Log.e("Url", Url);
                    new ApiConnection().connect(new OnApiResponseListener() {
                        @Override
                        public void onSuccess(JSONObject jsonObject) {
                            try {


                                Log.e("RESPONSE", jsonObject.toString());


                                JSONArray jsonArray = jsonObject.getJSONArray("UserInfo");
                                if (jsonArray.length() > 0) {
                                    for (int j = 0; j < 1; j++) {

                                        JSONObject jsn = jsonArray.getJSONObject(j);
                                        tvEmail.setText("Email : " + jsn.getString("EMAILID"));
                                        tvGender.setText("Gender : " + jsn.getString("GENDER"));
                                        tvMobile.setText("Phone : " + jsn.getString("PHONENUMBER"));
                                        tvName.setText(jsn.getString("FIRSTNAME") + " " + jsn.getString("LASTNAME"));


                                    }


                                } else {
                                    Toast.makeText(getActivity(), "No Category to display", Toast.LENGTH_SHORT).show();
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();

                            }

                        }

                        @Override
                        public void onFailed(String message) {
                            // avLoadingIndicatorView.hide();
                            Toast.makeText(getActivity(), "Oops something went wrong..", Toast.LENGTH_SHORT).show();

                        }
                    }, null, Url);

                } catch (Exception e) {


                }
            }
        });
    }
}
