package com.muskan.quizapp;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.formatter.DefaultValueFormatter;

import java.util.ArrayList;

/**
 * Created by Neeraj on 24-07-2017.
 */

public class QuizResultActivity extends AppCompatActivity {
    TextView result;
    int color[] = {Color.parseColor("#92d36e"), Color.parseColor("#ff3822")};
    Button btnShare, btnReQuiz,btnRate;
    int QuizId = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_result);

        result = (TextView) findViewById(R.id.tvResult);
        btnReQuiz = (Button) findViewById(R.id.btnShare);
        btnReQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(QuizResultActivity.this, ShareResultActivity.class);
                startActivity(i);
                finish();
            }
        });



        Bundle bundle = getIntent().getExtras();
       final int TotalQ = bundle.getInt("total_question");
       final int Correct = bundle.getInt("correct_answer");
        int Wrong = bundle.getInt("wrong_answer");
        QuizId = bundle.getInt("quiz_id");

        result.setText("Your Score : " + String.valueOf(Correct) + "/" + String.valueOf(TotalQ));

        PieChart pieChart = (PieChart) findViewById(R.id.piechart);
        pieChart.setDrawHoleEnabled(false);
        pieChart.setDescription("");
        ArrayList<Entry> yvalues = new ArrayList<Entry>();
        yvalues.add(new Entry(Correct, 0));
        yvalues.add(new Entry(Wrong, 1));
        PieDataSet dataSet = new PieDataSet(yvalues, "");
        dataSet.setValueFormatter(new DefaultValueFormatter(0));
        ArrayList<String> xVals = new ArrayList<String>();

        xVals.add("Correct");
        xVals.add("Wrong");
        PieData data = new PieData(xVals, dataSet);
        data.setValueFormatter(new DefaultValueFormatter(0));
        pieChart.setData(data);
        dataSet.setColors(color);
        data.setValueTextSize(16f);


    }


}
